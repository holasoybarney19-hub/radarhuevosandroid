package com.radarhuevos.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, history;
    EditText eggInput, timeInput, serverInput;
    TextView prediction, status;
    JSONArray entries = new JSONArray();
    final String PREF = "radar_data";
    int white = Color.rgb(238,243,255), muted = Color.rgb(174,187,215), panel = Color.rgb(21,29,51), purple = Color.rgb(124,92,255);

    int dp(int n){ return (int)(n*getResources().getDisplayMetrics().density); }
    TextView text(String s, int size, int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setPadding(dp(2),dp(5),dp(2),dp(5)); return t; }
    EditText edit(String hint){ EditText e=new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setTextColor(white); e.setHintTextColor(muted); e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple)); return e; }
    Button button(String label, Runnable action){ Button b=new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple)); b.setOnClickListener(v->action.run()); return b; }
    LinearLayout card(){ LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(14),dp(12),dp(14),dp(12)); c.setBackgroundColor(panel); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(6),0,dp(6)); root.addView(c,lp); return c; }

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(11,16,32)); getWindow().setNavigationBarColor(Color.rgb(11,16,32));
        android.content.SharedPreferences p=getSharedPreferences(PREF,0);
        try { entries=new JSONArray(p.getString("entries","[]")); } catch(Exception e) { entries=new JSONArray(); }
        ScrollView scroll=new ScrollView(this); scroll.setBackgroundColor(Color.rgb(11,16,32)); root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(16),dp(16),dp(16),dp(16)); scroll.addView(root); setContentView(scroll);
        root.addView(text("🥚 RADAR DE HUEVOS",26,white));
        root.addView(text("Versión Android gratuita · sin APK desconocidos",14,muted));
        LinearLayout c=card(); c.addView(text("🔎 DETECCIÓN",18,white));
        c.addView(text("Este prototipo no puede leer automáticamente el contenido de los servidores de Roblox. Solo marcará detecciones confirmadas cuando agregues datos observados; no inventa huevos ni horarios.",14,muted));
        status=text("Estado: sin conexión a datos de spawns",15,Color.rgb(251,191,36)); c.addView(status);
        LinearLayout form=card(); form.addView(text("Registrar huevo visto",18,white));
        eggInput=edit("Nombre / rareza del huevo"); form.addView(eggInput);
        serverInput=edit("Servidor (opcional)"); form.addView(serverInput);
        timeInput=edit("Hora (ej. 16:35)"); timeInput.setInputType(InputType.TYPE_CLASS_DATETIME); form.addView(timeInput);
        form.addView(button("GUARDAR APARICIÓN",()->addEntry()));
        LinearLayout pred=card(); pred.addView(text("⏱️ PRÓXIMA ESTIMACIÓN",18,white));
        prediction=text("Necesitás registrar dos apariciones del mismo huevo."); prediction.setTextSize(17); prediction.setTextColor(white); pred.addView(prediction);
        LinearLayout hist=card(); hist.addView(text("📜 HISTORIAL",18,white)); history=hist; renderHistory();
        LinearLayout help=card(); help.addView(text("Cómo conseguir detección automática",18,white));
        help.addView(text("Para detectar huevos grandes por servidor hace falta una API o fuente pública del juego que exponga esos datos. Si el juego no los publica, una app externa no puede saberlos de forma fiable solo por mirar la lista de servidores.",14,muted));
    }
    void addEntry(){
        String egg=eggInput.getText().toString().trim(); if(egg.isEmpty()){Toast.makeText(this,"Escribí el nombre del huevo",Toast.LENGTH_SHORT).show();return;}
        String time=timeInput.getText().toString().trim(); if(time.isEmpty()) time=new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date());
        try { JSONObject o=new JSONObject(); o.put("egg",egg); o.put("server",serverInput.getText().toString().trim()); o.put("time",time); o.put("ts",System.currentTimeMillis()); entries.put(o);
            getSharedPreferences(PREF,0).edit().putString("entries",entries.toString()).apply(); eggInput.setText(""); serverInput.setText(""); timeInput.setText(""); renderHistory(); Toast.makeText(this,"Aparición guardada",Toast.LENGTH_SHORT).show();
        }catch(Exception ignored){}
    }
    void renderHistory(){
        if(history==null)return;
        for(int i=history.getChildCount()-1;i>=1;i--) history.removeViewAt(i);
        if(entries.length()==0){history.addView(text("Todavía no hay registros.",14,muted));prediction.setText("Necesitás registrar dos apariciones del mismo huevo.");return;}
        for(int i=entries.length()-1;i>=0;i--){ JSONObject o=entries.optJSONObject(i); if(o!=null) history.addView(text("🥚 "+o.optString("egg")+" · "+o.optString("time")+(o.optString("server").isEmpty()?"":" · "+o.optString("server")),14,white)); }
        Map<String,List<Long>> times=new HashMap<>();
        for(int i=0;i<entries.length();i++){JSONObject o=entries.optJSONObject(i);if(o==null)continue;String name=o.optString("egg").toLowerCase(Locale.ROOT);times.computeIfAbsent(name,k->new ArrayList<>()).add(o.optLong("ts"));}
        String best=null; long interval=0;
        for(String name:times.keySet()){List<Long> a=times.get(name);if(a.size()>=2){long sum=0;for(int i=1;i<a.size();i++)sum+=a.get(i)-a.get(i-1);interval=sum/(a.size()-1);best=name;break;}}
        if(best!=null){long next=System.currentTimeMillis()+interval;prediction.setText("Estimación para "+best+": "+new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date(next))+" (aproximada; no confirmada).");}
        else prediction.setText("Registrá otra aparición del mismo huevo para calcular un intervalo estimado.");
    }
}
